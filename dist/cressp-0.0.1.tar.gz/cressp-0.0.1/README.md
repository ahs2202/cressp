# Cross-Reactive-Epitope-Search-using-Structural-Properties-of-proteins (cressp)
 a program to find cross-reactive epitopes with structural information from known protein structures.
