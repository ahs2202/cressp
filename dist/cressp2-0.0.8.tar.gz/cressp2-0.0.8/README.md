# Cross-Reactive-Epitope-Search-using-Structural-Properties-of-Proteins (cressp2)
 a program to find cross-reactive epitopes with structural information from known protein structures.
