# Version of cressp2 package
__version__ = "0.0.10"

# import modules

# __all__ = [ "STR", "MAP", "PDB", "ONT", 'RNA', 'UniProt', 'main' ]